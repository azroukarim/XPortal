import os
import sys
import py_compile
import shutil

def compile_plugin():
    # Get the directory of the script
    plugin_dir = os.path.dirname(os.path.abspath(__file__))
    
    print("=========================================")
    print("XPortal Plugin Compiler")
    print("=========================================")
    print("WARNING: This will compile all .py files to .pyc and DELETE the original .py files!")
    print("Make sure you have a BACKUP of your source code before proceeding.")
    print("Starting compilation in: " + plugin_dir)
    print("Python version: " + sys.version.split()[0])
    
    # Python 2/3 compatibility for input
    try:
        user_input = raw_input("\nType 'yes' to continue and delete source files: ")
    except NameError:
        user_input = input("\nType 'yes' to continue and delete source files: ")
        
    if user_input.lower() != 'yes':
        print("Compilation aborted.")
        return
    
    # 1. Find all .py files except this script itself (including subdirectories)
    py_files = []
    for root, dirs, files in os.walk(plugin_dir):
        # Skip __pycache__ directories
        if "__pycache__" in root:
            continue
            
        for f in files:
            if f.endswith(".py") and f != os.path.basename(__file__):
                py_files.append(os.path.join(root, f))
            
    if not py_files:
        print("No .py files found to compile.")
        return

    # 2. Compile each file
    for full_path in py_files:
        compiled_path = full_path + "c" 
        
        try:
            rel_path = os.path.relpath(full_path, plugin_dir)
            print("Compiling: " + rel_path + " ... ", end="")
            # compile it
            py_compile.compile(full_path, cfile=compiled_path)
            
            # 3. If compilation succeeded, delete the original .py file
            if os.path.exists(compiled_path):
                os.remove(full_path)
                print("Done.")
            else:
                print("Failed. (.pyc not created)")
        except Exception as e:
            print("Error: " + str(e))
            
    # Clean up __pycache__ folders
    for root, dirs, files in os.walk(plugin_dir, topdown=False):
        for name in dirs:
            if name == "__pycache__":
                try:
                    shutil.rmtree(os.path.join(root, name))
                except:
                    pass
            
    print("=========================================")
    print("Compilation Complete! The plugin is now closed-source.")
    print("You can now safely distribute the XPortal folder.")
    print("NOTE: Do not forget to delete this compile_plugin.py script before distribution.")
    print("=========================================")

if __name__ == "__main__":
    compile_plugin()
